const menu = document.querySelector('#mobileMenu')
const menuLinks = document.querySelector('.navbarMenu')

menu.addEventListener('click', function(){
    menu.classList.toggle('isActive');
    menuLinks.classList.toggle('active');
})

function validate(){
    var x = document.forms["question"]["answer"].value;
    if (x == ""){
        document.getElementById("box").style.color= "red";
    }
    else if (x == "35cm"){
        alert("correct!");
    }
}
