package co2103.hw1.controller;

import co2103.hw1.domain.Website;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import static co2103.hw1.Hw1Application.websites;

public class WebsiteValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return Website.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        Website website = (Website) target;
        for (Website w : websites) {
            if (w.getId() == website.getId()){
                errors.rejectValue("id", "", "ID exists.");
            }
        }
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address", "",
                "There needs to be an address");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "title", "",
                "There needs to be a title");
    }
}
