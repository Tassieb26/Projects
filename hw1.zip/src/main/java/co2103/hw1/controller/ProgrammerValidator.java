package co2103.hw1.controller;

import co2103.hw1.domain.Programmer;
import co2103.hw1.domain.Website;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import static co2103.hw1.Hw1Application.websites;

public class ProgrammerValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return Programmer.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        Programmer programmer = (Programmer) target;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "",
                "Please add a name.");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "role", "",
                "Please add a role.");
        System.out.println(programmer.getSkill());
        if (!programmer.getSkill().contains("HTML")){
            if (!programmer.getSkill().contains("JavaScript")){
                if (!programmer.getSkill().equals("CSS")){
                    errors.rejectValue("skill", "", "Please enter a valid skill.");
                }
            }
        }

        if (programmer.getExperience() < 0 || programmer.getExperience() > 65){
            errors.rejectValue("experience", "", "Years of experience must be between 0 and 65.");
        }
    }
}
