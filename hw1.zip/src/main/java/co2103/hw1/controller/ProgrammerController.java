package co2103.hw1.controller;

import co2103.hw1.Hw1Application;
import co2103.hw1.domain.Programmer;
import co2103.hw1.domain.Website;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static co2103.hw1.Hw1Application.websites;

@Controller
public class ProgrammerController {
    @RequestMapping("/programmers")
    public String listProgrammers(Model model, @RequestParam int website){

        for (Website w : websites){
            if (w.getId() == website){
                model.addAttribute("programmers", w.getProgrammers());
                model.addAttribute("websiteID", website);
                break;
            }
        }
        return "programmers/list";
    }

    @RequestMapping("/newProgrammer")
    public String newProgrammer(Model model, @RequestParam int website){
        model.addAttribute("programmer", new Programmer());
        model.addAttribute("websiteID", website);
        return "programmers/form";
    }

    @RequestMapping("/addProgrammer")
    public String addProgrammer(@Valid @ModelAttribute Programmer programmer, BindingResult result, @RequestParam int website, Model model){

        if (result.hasErrors()) {
            model.addAttribute("websiteID", website);
            return "programmers/form";
        }
        model.addAttribute("websiteID", website);
        for (Website w : websites){
            if (w.getId() == website) {
                w.getProgrammers().add(programmer);
            }
        }
        return "redirect:/websites";
    }

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.addValidators(new ProgrammerValidator());
    }
}
