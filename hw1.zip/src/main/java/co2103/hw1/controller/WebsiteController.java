package co2103.hw1.controller;

import co2103.hw1.Hw1Application;
import co2103.hw1.domain.Programmer;
import co2103.hw1.domain.Website;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.validation.Valid;

import java.util.ArrayList;
import java.util.List;

import static co2103.hw1.Hw1Application.websites;

@Controller
public class WebsiteController {
    @RequestMapping("/websites")
    public String listWebsites(Model model){

        List<Website> websites = Hw1Application.websites;

        model.addAttribute("websites", websites);
        return("websites/list");
    }

    @RequestMapping("/newWebsite")
    public String newWebsite(Model model){
        model.addAttribute("website", new Website());
        return("websites/form");
    }

    @RequestMapping("/addWebsite")
    public String addWebsite(@Valid @ModelAttribute Website website, BindingResult result, Model model){
        if (result.hasErrors()) {
            return "websites/form";
        }
        List<Programmer> programmers = new ArrayList<>();
        website.setProgrammers(programmers);
        websites.add(website);
        return "redirect:/";
    }

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.addValidators(new WebsiteValidator());
    }

}
