package co2103.hw1;

import co2103.hw1.domain.Programmer;
import co2103.hw1.domain.Website;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class Hw1Application {
    public static List<Website> websites = new ArrayList<>();
    public static List<Programmer> programmerList = new ArrayList<>();

    public static void main(String[] args) {
        SpringApplication.run(Hw1Application.class, args);

        Programmer p1 = new Programmer();
        p1.setName("Emma Watson");
        p1.setRole("Senior developer");
        p1.setSkill("Java");
        p1.setExperience(8);
        programmerList.add(p1);

        Programmer p2 = new Programmer();
        p2.setName("John Cena");
        p2.setRole("Junior developer");
        p2.setSkill("HTML");
        p2.setExperience(2);
        programmerList.add(p2);

        Website website = new Website();
        website.setId(10);
        website.setAddress("www.google.com");
        website.setTitle("Google");
        website.setProgrammers(programmerList);
        websites.add(website);

    }
}