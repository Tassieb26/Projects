public class EX002 extends Module {
    private double examMark;
    private double finalMark;

    public EX002(String name, int stat) {
        super(name, stat);
    }

    public double getExamMark() {
        return examMark;
    }

    public void setExamMark(double examMark) {
        this.examMark = examMark;
    }

    @Override
    public double getFinalMark() {
        return finalMark;
    }

    @Override
    public void setFinalMark() {
        this.finalMark = examMark;
    }
}
