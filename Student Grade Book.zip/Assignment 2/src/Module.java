public abstract class Module {
    private String moduleName;
    private int status;
    private double finalMark;
    public Module(String name, int stat){
        moduleName = name;
        status = stat;
    }

    public String getName() {
        return moduleName;
    }

    public void setName(String name) {
        this.moduleName = name;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public double getFinalMark() {
        return finalMark;
    }

    public abstract void setFinalMark();

}
