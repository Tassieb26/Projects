public class CE003 extends Module{

    private double[] homework;
    private double homeworkMark;
    private double examMark;

    private double finalMark;

    public CE003(String name, int stat){
        super(name, stat);
    }

    public double[] getHomework() {
        return homework;
    }

    public void setHomework(double[] homework) {
        this.homework = homework;
    }

    public double getHomeworkMark() {
        return homeworkMark;
    }

    public void setHomeworkMark() {
        double total = 0;
        for (int i = 0; i < homework.length; i++){
            total += homework[i];
        }
        this.homeworkMark = total/4;
    }

    public double getExamMark() {
        return examMark;
    }

    public void setExamMark(double examMark) {
        this.examMark = examMark;
    }

    @Override
    public double getFinalMark() {
        return finalMark;
    }

    @Override
    public void setFinalMark() {
        this.finalMark = (homeworkMark * 0.4) + (examMark * 0.6);
    }
}
