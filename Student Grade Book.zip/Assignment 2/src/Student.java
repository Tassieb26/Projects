import java.text.DecimalFormat;

public class Student {
    private String ID;
    private String forename;
    private String surname;
    private CW001 module1;
    private EX002 module2;
    private CE003 module3;

    private double finalMark;

    public Student(){
    }

    public String getID() {
        return ID;
    }
    public void setID(String ID) {
        this.ID = ID;
    }
    public String getForename() {
        return forename;
    }
    public void setForename(String forename) {
        this.forename = forename;
    }
    public String getSurname() {
        return surname;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }

    // Following functions are used to create instances of each module
    public void getModule1() {
        DecimalFormat df = new DecimalFormat("####0.00");  // Use this to format results to 2dp

        double hMark = module1.getHomeworkMark();
        double pMark = module1.getProjectMark();
        double fMark = module1.getFinalMark();

        System.out.format("%3s %15s %15s %15s %15s %15s", ID, forename, surname, df.format(hMark)+" %",
                df.format(pMark)+" %", df.format(fMark)+" %");  // values are separated into columns
        System.out.println();
    }
    public void setModule1(CW001 module1) {
        this.module1 = module1;
    }
    public void getModule2() {
        DecimalFormat df = new DecimalFormat("####0.00");  // Use this to format results to 2dp

        double fMark = module2.getFinalMark();

        System.out.format("%3s %15s %15s %12s", ID, forename, surname, df.format(fMark)+" %");  // values are separated into columns
        System.out.println();
    }
    public void setModule2(EX002 module2) {
        this.module2 = module2;
    }
    public void getModule3() {
        DecimalFormat df = new DecimalFormat("####0.00");  // Use this to format results to 2dp

        double hMark = module3.getHomeworkMark();
        double eMark = module3.getExamMark();
        double fMark = module3.getFinalMark();

        System.out.format("%3s %15s %15s %15s %15s %15s", ID, forename, surname, df.format(hMark)+" %",
                df.format(eMark)+" %", df.format(fMark)+" %");  // values are separated into columns
        System.out.println();
    }
    public void setModule3(CE003 module3) {
        this.module3 = module3;
    }


    public void getFinalMark(){
        DecimalFormat df = new DecimalFormat("####0.00");  // Use this to format results to 2dp

        double c1Mark = module1.getFinalMark();
        double c2Mark = module2.getFinalMark();
        double c3Mark = module3.getFinalMark();


        System.out.format("%3s %15s %15s %15s %15s %15s", ID, forename, surname,
                df.format(c1Mark)+" %", df.format(c2Mark)+" %", df.format(c3Mark)+" %");  // values are separated into columns
        System.out.println();
    }


}
