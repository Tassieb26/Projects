public class CW001 extends Module{
    private double[] homework;

    private double homeworkMark;
    private double projectMark;
    private double finalMark;

    public CW001(String name, int stat){
        super(name, stat);
    }


    public double[] getHomework() {
        return homework;
    }

    public void setHomework(double[] homework) {
        this.homework = homework;
    }

    public double getHomeworkMark() {
        return homeworkMark;
    }

    public void setHomeworkMark() {
        double total = 0;
        for (int i = 0; i < homework.length; i++){
            total += homework[i];
        }
        this.homeworkMark = total/3;
    }

    public double getProjectMark() {
        return projectMark;
    }

    public void setProjectMark(double projectMark) {
        this.projectMark = projectMark;
    }

    @Override
    public double getFinalMark() {
        return finalMark;
    }

    @Override
    public void setFinalMark() {

        this.finalMark = (homeworkMark * 0.5) + (projectMark * 0.5);
    }

}
