import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of students: ");   // Collect the number of students in the class
        int numStudents = sc.nextInt();

        Student[] allStudents = new Student[numStudents];  // Create an array of type Student

        for (int s = 0; s < numStudents; s++) {
            Scanner input = new Scanner(System.in);
            allStudents[s] = new Student();

            System.out.println("*************** INPUT STUDENT DETAILS ***************");

            // Fill in student's name and surname
            System.out.print("Please enter the first name for student " + (s + 1) + ": ");
            String firstName = input.nextLine();
            System.out.print("Please enter the surname for student " + (s + 1) + ": ");
            String secondName = input.nextLine();

            allStudents[s].setID("00"+(s+1));
            allStudents[s].setForename(firstName);
            allStudents[s].setSurname(secondName);

            // Instantiate each module per student
            CW001 c1 = new CW001("CW001", 0);  // CW001 created and connected to student instance
            allStudents[s].setModule1(c1);
            EX002 c2 = new EX002("EX002", 1);  // EX002 created and connected to student instance
            allStudents[s].setModule2(c2);
            CE003 c3 = new CE003("CE003", 2);  // CE003 created and connected to student instance
            allStudents[s].setModule3(c3);

            // Fill in marks for CW001
            System.out.println("-------------- INPUT CW001 RESULTS --------------");
            c1.setHomework(HomeworkArray(3));
            c1.setHomeworkMark();

            System.out.print("Please enter the project mark for student " + (s+1) + ": ");
            double projectMark = input.nextDouble();

            c1.setProjectMark(projectMark);
            c1.setFinalMark();

            // Fill in marks for EX002
            System.out.println("-------------- INPUT EX002 RESULTS --------------");
            System.out.print("Please enter the exam mark for student " + (s+1) + ": ");
            double examMark1 = input.nextDouble();

            c2.setExamMark(examMark1);
            c2.setFinalMark();

            // Fill in marks for CE003
            System.out.println("-------------- INPUT CE003 RESULTS --------------");
            c3.setHomework(HomeworkArray(4));
            c3.setHomeworkMark();

            System.out.print("Please enter the exam mark for student " + (s+1) + ": ");
            double examMark2 = input.nextDouble();
            c3.setExamMark(examMark2);

            c3.setFinalMark();
        }

        // DISPLAYING TABLES
        int choice = 0;
        try{
            while (choice != 5){
                System.out.println("\n");
                System.out.println("Which table would you like to like to view: " +
                        "\n 1 - Marks for all modules" +
                        "\n 2 - Marks for CW001" +
                        "\n 3 - Marks for EX002" +
                        "\n 4 - Marks for CE003" +
                        "\n 5 - Quit");
                choice = sc.nextInt();

                if (choice == 1){
                    // Table header
                    System.out.println("\n-------------------------------- MARKS FOR MODULES --------------------------------");
                    System.out.printf("%3s %15s %15s %15s %15s %15s", "ID", "Name", "Surname", "CW001", "EX002", "CE003");
                    System.out.println("\n-----------------------------------------------------------------------------------");

                    for (int j = 0; j < allStudents.length; j++){
                        allStudents[j].getFinalMark();
                    }
                }
                else if (choice == 2){
                    // Table header for CW001
                    System.out.println("\n-------------------------------- MARKS FOR CW001 --------------------------------");
                    System.out.printf("%3s %15s %15s %15s %15s %15s", "ID", "Name", "Surname", "Homeworks", "Project Mark", "Final Mark");
                    System.out.println("\n---------------------------------------------------------------------------------");

                    for (int j = 0; j < allStudents.length; j++) {
                        allStudents[j].getModule1();
                    }
                }
                else if (choice == 3){
                    // Table header for EX002
                    System.out.println("\n------------------------- MARKS FOR EX002 ---------------------------");
                    System.out.printf("%3s %15s %15s %15s", "ID", "Name", "Surname", "Final Mark");
                    System.out.println("\n---------------------------------------------------------------------");

                    for (int j = 0; j < allStudents.length; j++) {
                        allStudents[j].getModule2();
                    }
                }
                else if (choice == 4) {
                    // Table header
                    System.out.println("\n---------------------------------- MARKS FOR CE003 ----------------------------------");
                    System.out.printf("%3s %15s %15s %15s %15s %15s", "ID", "Name", "Surname", "Homeworks", "Exam Mark", "Final Mark");
                    System.out.println("\n-------------------------------------------------------------------------------------");

                    for (int j = 0; j < allStudents.length; j++){
                        allStudents[j].getModule3();
                    }
                }
                else if (choice > 5 || choice < 1){
                    System.out.println("Please enter a valid option.");
                }
            }
        }
        catch(Exception e){
            System.out.println("Sorry, there was an error, please try again.");
        }
    }



    // The function homeworkArray creates and returns an array of homework marks
    public static double[] HomeworkArray(int length){
        Scanner input = new Scanner(System.in);

        double[] homeworks = new double[length];
        for (int k = 0; k < length; k++) {
            System.out.print("Enter homework mark " + (k+1) + ": ");
            double mark = input.nextDouble();
            while (mark < 0 || mark > 100){
                System.out.println("Please enter a valid mark: ");
                mark = input.nextDouble();
            }
            homeworks[k] = mark;
        }
        return homeworks;
    }



}